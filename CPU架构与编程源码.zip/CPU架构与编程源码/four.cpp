#include <iostream>
#include <vector>
#include <chrono>
using namespace std;
using namespace chrono;
#define N 1000

long long sum(const vector<long long>& arr, long long left, long long right) {
    if (left == right) return arr[left];
    if (left + 1 == right) return arr[left] + arr[right];
    long long mid = (left + right) / 2;
    return sum(arr, left, mid) + sum(arr, mid + 1, right);
}

int main() {
    const int n1 = N*10000;
    vector<long long> arr(n1, 1);
    long long res = 0;
    auto start = high_resolution_clock::now();
    for (int i = 0; i < 100; i++) {
        res = sum(arr, 0, n1 - 1);
    }
    auto end = high_resolution_clock::now();
    duration<double, milli> duration1 = end - start;
    cout << "res: " << res << endl;
    cout << "time: " << duration1.count()/100 << " ms" << endl;

    

    return 0;
}