#include <iostream>
#include <vector>
#include <chrono>
using namespace std;
using namespace chrono;
#define N 1000
long long sum(const vector<long long>& arr) {
   long long sum = 0;
   for (long long num : arr) {
       sum += num;
   }
   return sum;
}

int main() {
   
   const long long n = N * 10000; 
   vector<long long> arr(n, 1);   
    long long result = 0;
   
   auto start = high_resolution_clock::now();
   for(int i = 0;i<100;i++){
      result = sum(arr);
   }
      
   
   auto end = high_resolution_clock::now();

   
   duration<double, milli> duration = end - start;
   cout << "res: " << result << endl;
   cout << "time: " << duration.count()/100 << " ms" << endl;

   return 0;
}