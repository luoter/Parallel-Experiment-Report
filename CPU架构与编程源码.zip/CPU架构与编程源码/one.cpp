#include<iostream>
#include<vector>
#include <chrono>
using namespace std;
using namespace chrono;
const int n = 4096;
int a[n][n];


void sum(vector<int>& result, const vector<int>& v)
{
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            result[i] += a[j][i] * v[j];
        }
    }
}

int main()
{
    
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            a[i][j] = i + j;

    vector<int> v(n, 5);
    vector<int> result(n, 0);

    auto start = high_resolution_clock::now();
    for (int k = 0; k < 1000; k++) {
        sum(result, v);
    }
    auto end = high_resolution_clock::now();
    duration<double, milli> duration = end - start;
    cout << "time:" << duration.count()/1000 << " ms" << endl;

    return 0;
}